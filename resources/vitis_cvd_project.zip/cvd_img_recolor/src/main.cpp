/**********
 Copyright (c) 2021, Xilinx, Inc.
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:

 1. Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 3. Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **********/

#include <algorithm>
#include <cstring>
#include <iostream>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// This extension file is required for stream APIs
#include "CL/cl_ext_xilinx.h"
// This file is required for OpenCL C++ wrapper APIs
#include "xcl2.hpp"

// Project include files
#include "grid.h"
#include "solver.h"
#include "dataset.h"
#include "utils.h"

#define CENTERWHITE 1

grid *Grid;
solver *Solver;
dataset *Dataset;

auto constexpr num_cu = 10;

int main(int argc, char **argv) {
	char *imgpath = "testeimg1.jpg";
	// Check input arguments
	if (argc != 3) {
		std::cout << "Usage: " << argv[0] << " <XCLBIN File> <IMG PATH> "
				<< std::endl;
		return EXIT_FAILURE;
	}
	// Read FPGA binary file
	auto binaryFile = argv[1];
	// Check if the user defined the # of elements
	imgpath = argv[2];

	// OpenCL Host Code Begins.
	// OpenCL objects
	cl::Device device;
	cl::Context context;
	cl::CommandQueue q;
	cl::Program program;
	// cl::Kernel krnl_calctaxons;
	std::vector<cl::Kernel> krnl_calctaxons(num_cu);
	cl_int err;

	// get_xil_devices() is a utility API which will find the Xilinx
	// platforms and will return list of devices connected to Xilinx platform
	auto devices = xcl::get_xil_devices();

	// read_binary_file() is a utility API which will load the binaryFile
	// and will return the pointer to file buffer.
	auto fileBuf = xcl::read_binary_file(binaryFile);
	cl::Program::Binaries bins { { fileBuf.data(), fileBuf.size() } };
	bool valid_device = false;
	for (unsigned int i = 0; i < devices.size(); i++) {
		device = devices[i];
		// Creating Context and Command Queue for selected Device
		OCL_CHECK(err, context = cl::Context(device, NULL, NULL, NULL, &err));
		OCL_CHECK(err,
				q = cl::CommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE | CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE, &err));
		std::cout << "Trying to program device[" << i << "]: "
				<< device.getInfo<CL_DEVICE_NAME>() << std::endl;
		cl::Program program(context, { device }, bins, NULL, &err);
		if (err != CL_SUCCESS) {
			std::cout << "Failed to program device[" << i
					<< "] with xclbin file!\n";
		} else {
			std::cout << "Device[" << i << "]: program successful!\n";
			// Creating Kernels
			for (int i = 0; i < num_cu; i++) {
				OCL_CHECK(err,
						krnl_calctaxons[i] = cl::Kernel(program,
								"krnl_calctaxons", &err));
			}
			valid_device = true;
			break; // we break because we found a valid device
		}
	}
	if (!valid_device) {
		std::cout << "Failed to program any device found, exit!\n";
		exit(EXIT_FAILURE);
	}

	/* Start of host program */
	// 1st step: Initialize Data Structures
	Grid = new grid(PROTANOPE, T_GRID);
	printf("Grid constructed\n");
	Dataset = new dataset(imgpath);
	printf("Dataset constructed\n");
	Solver = new solver(Grid, Dataset);
	printf("Solver constructed\n");

	/* Multiple Compute Units */
	int datasize = Dataset->Datasize;
	auto chunk_size = datasize / num_cu;
	std::vector<cl::Buffer> input_dataset(num_cu);
	std::vector<cl::Buffer> output_taxons(num_cu);

	for (int i = 0; i < num_cu; i++) {
		OCL_CHECK(err,
				input_dataset[i] = cl::Buffer(context, CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY, chunk_size * sizeof(XYPos), Dataset->Location + i * chunk_size, &err));
		OCL_CHECK(err,
				output_taxons[i] = cl::Buffer(context, CL_MEM_USE_HOST_PTR | CL_MEM_WRITE_ONLY, chunk_size * sizeof(int), Solver->Taxons + i * chunk_size, &err));
	}
	OCL_CHECK(err,
			cl::Buffer input_graph(context, CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY, T_GRID * sizeof(XYPos), Grid->Location, &err));

	// int datasize = Dataset->Datasize;
	// Define buffers in FPGA
	// OCL_CHECK(err,
	// 		cl::Buffer input_graph(context, CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY, T_GRID * sizeof(XYPos), Grid->Location, &err));
	// OCL_CHECK(err,
	// 		cl::Buffer input_dataset(context, CL_MEM_USE_HOST_PTR | CL_MEM_READ_ONLY, datasize * sizeof(XYPos), Dataset->Location, &err));
	// OCL_CHECK(err,
	// 		cl::Buffer output_taxons(context, CL_MEM_USE_HOST_PTR | CL_MEM_WRITE_ONLY, datasize * sizeof(int), Solver->Taxons, &err));

	// Setting Kernel Arguments krnl_vadd
	// OCL_CHECK(err, err = krnl_calctaxons.setArg(0, input_graph));
	// OCL_CHECK(err, err = krnl_calctaxons.setArg(1, input_dataset));
	// OCL_CHECK(err, err = krnl_calctaxons.setArg(2, output_taxons));
	// OCL_CHECK(err, err = krnl_calctaxons.setArg(3, datasize));

	for (int i = 0; i < num_cu; i++) {
		int narg = 0;

		// Setting kernel arguments
		OCL_CHECK(err, err = krnl_calctaxons[i].setArg(narg++, input_graph));
		OCL_CHECK(err, err = krnl_calctaxons[i].setArg(narg++, input_dataset[i]));
		OCL_CHECK(err, err = krnl_calctaxons[i].setArg(narg++, output_taxons[i]));
		OCL_CHECK(err, err = krnl_calctaxons[i].setArg(narg++, chunk_size));

		OCL_CHECK(err, err = q.enqueueMigrateMemObjects( { input_dataset[i] }, 0));
	}
	OCL_CHECK(err, err = q.finish());

	// Algorithm iterations
	int max_epochs = Solver->numEpochs;
//	while (Solver->CurrentEpoch < max_epochs) {
		printf("Doing Epoch %d\n", Solver->CurrentEpoch);

		Solver->preConstructSysMatrix();

		/* FPGA kernel */
		// Migrate the current node positions to the FPGA
		OCL_CHECK(err, err = q.enqueueMigrateMemObjects( { input_graph }, 0));
		OCL_CHECK(err, err = q.finish());

		// Execute the kernel
		for (int i = 0; i < num_cu; i++) {
			OCL_CHECK(err, err = q.enqueueTask(krnl_calctaxons[i]));
		}
		OCL_CHECK(err, err = q.finish());

		// Get result from the FPGA
		for (int i = 0; i < num_cu; i++) {
			OCL_CHECK(err, err = q.enqueueMigrateMemObjects({output_taxons[i]}, CL_MIGRATE_MEM_OBJECT_HOST));
		}
		OCL_CHECK(err, err = q.finish());
		/* End of FPGA Kernel */

		// This is CPU version
	//		Solver->calcTaxons();
		Solver->constructSysMatrix();
		Solver->solveLS();
		Solver->CurrentEpoch++;
//	}
#if CENTERWHITE
	Solver->centerWhite();
#endif
	printf("projection step\n");
	Solver->projectPoints();
	Solver->drawRecolored("svimg.jpg");
	printf("image saved as svimg.jpg\n");

	// OpenCL Host Code Ends

	return 0;
}
