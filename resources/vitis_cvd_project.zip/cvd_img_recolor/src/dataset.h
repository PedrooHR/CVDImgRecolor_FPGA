/*
 * dataset.h
 *
 *  Created on: 17/03/2018
 *      Author: phr
 */

#ifndef DATASET_H_
#define DATASET_H_

#define cimg_display 0
#define cimg_use_jpeg

#include <vector>
#include <CImg.h>
#include "utils.h"

typedef struct Pixel {
	float* RGB;
	float* Lab;
	float R;
	float G;
	float B;
	float L;
	float a;
	float b;
	float PL;
	float Pa;
	float Pb;
	int id;
	int closest_node;
} Pixel;

class dataset {
public:
	int width;
	int height;

	Pixel * Datapoints;
#if VERSION == 1
	XYPos *Location;
#elif VERSION == 2
	float *LocationX;
	float *LocationY;
#endif

	int Datasize;
	dataset(const char*imgPath);
};

#endif /* DATASET_H_ */
