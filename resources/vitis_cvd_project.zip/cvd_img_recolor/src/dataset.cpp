/*
 * dataset.cpp
 *
 *  Created on: 17/03/2018
 *      Author: phr
 */

#include "dataset.h"
#include <cassert>
#include "utils.h"

dataset::dataset(const char*imgPath){
	int local_id = 0;
	cimg_library::CImg<unsigned int> image(imgPath);
	width = image.width();
	height = image.height();
	int size = width * height;

	Datapoints = (Pixel *) malloc (size * sizeof(Pixel));

    void *ptr = nullptr;
    void *ptr2 = nullptr;
#if VERSION == 1
	assert(posix_memalign(&ptr, 4096, size * sizeof(XYPos)) == 0);
	Location = reinterpret_cast<XYPos *>(ptr);
#elif VERSION == 2
	assert(posix_memalign(&ptr, 4096, size * sizeof(float)) == 0);
	assert(posix_memalign(&ptr2, 4096, size * sizeof(float)) == 0);
	LocationX = reinterpret_cast<float *>(ptr);
	LocationY = reinterpret_cast<float *>(ptr2);
#endif

	
	cimg_forXY(image,x,y) {
		Datapoints[local_id].id = local_id;
		Datapoints[local_id].closest_node = -1;
		//create RGB
		Datapoints[local_id].RGB = (float*) malloc(3* sizeof(float));
		Datapoints[local_id].R = Datapoints[local_id].RGB[0] = image(x,y,0)/255.0f;
		Datapoints[local_id].G = Datapoints[local_id].RGB[1] = image(x,y,1)/255.0f;
		Datapoints[local_id].B = Datapoints[local_id].RGB[2] = image(x,y,2)/255.0f;
		//create Lab
		std::vector <float> lab_color = getLabColor(image(x,y,0), image(x,y,1), image(x,y,2));
		Datapoints[local_id].Lab = (float*) malloc(3* sizeof(float));
		Datapoints[local_id].L = Datapoints[local_id].Lab[0] = lab_color[0];
#if VERSION == 1
		Location[local_id].x = Datapoints[local_id].a = Datapoints[local_id].Lab[1] = lab_color[1];
		Location[local_id].y = Datapoints[local_id].b = Datapoints[local_id].Lab[2] = lab_color[2];
#elif VERSION == 2
		LocationX[local_id] = Datapoints[local_id].a = Datapoints[local_id].Lab[1] = lab_color[1];
		LocationY[local_id] = Datapoints[local_id].b = Datapoints[local_id].Lab[2] = lab_color[2];
#endif

		local_id++;
	};
	Datasize = size;
}
