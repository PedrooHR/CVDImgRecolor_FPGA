/*
 * grid.cpp
 *
 *  Created on: 17/03/2018
 *      Author: phr
 */

#include "grid.h"

#include <iostream>
#include <cassert>
#include "utils.h"

grid::grid(int type, int graph_size) {
	GRAPH_SIZE = graph_size;
	numEdges = GRAPH_SIZE - 1;
	numRibs  = GRAPH_SIZE - 2;
	Graph = (Node *) malloc (GRAPH_SIZE * sizeof(Node));

    void *ptr = nullptr;
    void *ptr2 = nullptr;
#if VERSION == 1
	assert(posix_memalign(&ptr, 4096, GRAPH_SIZE * sizeof(XYPos)) == 0);
	Location = reinterpret_cast<XYPos*>(ptr);
#elif VERSION == 2
	assert(posix_memalign(&ptr, 4096, GRAPH_SIZE * sizeof(float)) == 0);
	assert(posix_memalign(&ptr2, 4096, GRAPH_SIZE * sizeof(float)) == 0);
	LocationX = reinterpret_cast<float *>(ptr);
	LocationY = reinterpret_cast<float *>(ptr2);
#endif



	// do graphnodes
	if (type == PROTANOPE){
		//PROTANOPE LIMITS
		A = {8.648425, -73.086372, 56.664734};
		C = {-14.907598, 86.293831, 89.536812};

		miAB = A[1] / A[0];
		miBC = C[1] / C[0];

		float x_step  = fabs((A[0] - C[0]) / (GRAPH_SIZE * 1.0));
		float x_start = C[0];


		for(int i = 0; i < GRAPH_SIZE; i++){
			Graph[i].id = i;
			Graph[i].Position = (float*) malloc (2*sizeof(float));
#if VERSION == 1
			Location[i].x = Graph[i].Position[0] = (x_start <= 0) ? miBC * x_start : miAB * x_start;
			Location[i].y = Graph[i].Position[1] = -x_start;
#elif VERSION == 2
			LocationX[i] = Graph[i].Position[0] = (x_start <= 0) ? miBC * x_start : miAB * x_start;
			LocationY[i] = Graph[i].Position[1] = -x_start;
#endif
			Graph[i].CVDposition = (float*) malloc (2*sizeof(float));
			Graph[i].CVDposition[0] = x_start;
			Graph[i].CVDposition[1] = (x_start <= 0) ? miBC * x_start : miAB * x_start;
			Graph[i].Weight = 1.0f;
			Graph[i].a = (x_start <= 0) ? miBC * x_start : miAB * x_start;
			Graph[i].b = -x_start;
			x_start += x_step;
		}
	}

	// do edges
	for (int i = 0; i < GRAPH_SIZE - 1; i++){
		std::vector<int> t = {i, i + 1};
		Edges.push_back(t);
	}

	// do ribs
	for (int i = 0; i < GRAPH_SIZE - 2; i++){
		std::vector<int> t = {i + 1, i, i + 2};
		Ribs.push_back(t);
	}
}

